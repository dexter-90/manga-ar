# manga-dl4
### To install:
```bash
pip3 install manga-dl4
```